#include <iostream>
#include "arm_neon.h"

using namespace std;

extern "C" void add3 (uint8x16_t *data);
extern "C" int total (int32_t *data);

class neon_test  {
	public:

		neon_test () {
			int i;
			for(i=0; i<16; i++) {
				uint8_data[i] = i; 
			}
		}

		void test_add3() {
			/* Create the vector with our data. */
			uint8x16_t data;

			/* Load our custom data into the vector register. */
			data = vld1q_u8 (uint8_data);

			print_uint8 (data, "data");

			/* Call of the add3 function. */
			add3(&data);

			print_uint8 (data, "data (new)");
		}   

		void print_uint8 (uint8x16_t data, const char* name) {
			int i;
			static uint8_t p[16];

			vst1q_u8 (p, data);

			cout << name << std::endl;
			for (i = 0; i < 16; i++) {
				cout << int(p[i]) << " "; 
			}
			printf ("\n");
		}

	private:
		uint8_t uint8_data[];
};



int main () {
	neon_test test;

	test.test_add3();

	return 0;
}
